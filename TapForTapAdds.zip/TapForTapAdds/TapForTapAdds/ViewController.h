//
//  ViewController.h
//  TapForTapAdds
//
//  Created by   on 02/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TapForTap.h"

@interface ViewController : UIViewController

@end
